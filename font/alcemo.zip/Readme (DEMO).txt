`
This demo font is free for PERSONAL USE, but any donation are very appreciated

Here is the link to purchase commercial license:
https://creativemarket.com/PandekaStudio/291241148-Alcemo-Hand-Drawn-Vintage-Serif?u=PandekaStudio

For Corporate use you have to purchase Corporate license

If you need a custom license please contact us at
pandekastudio@gmail.com

Paypal donation : https://paypal.me/rhesmannisa

Visit our store for more great fonts :
https://creativemarket.com/PandekaStudio?u=PandekaStudio

Thank you and Enjoy :)


-------------------------------------------


INDONESIA - MOHON DIBACA:

Dengan menginstall font ini, Anda setuju untuk terikat oleh persyaratan dan peraturan yang kami berikan

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use", atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, atau Perusahaan/Korporasi.

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk ( baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

3. Menggunakan font ini untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya NATIONAL CORPORATE LICENSE atau 100 kali harga dari Lisensi Standard.    

Lisensi bisa anda beli di :
https://creativemarket.com/PandekaStudio/291241148-Alcemo-Hand-Drawn-Vintage-Serif?u=PandekaStudio

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami:
pandekastudio@gmail.com

Terima kasih, mohon saling support ya:)