# Solway
by Northern Block

Solway is a five weight slab serif family, designed by the [Northern Block](https://thenorthernblock.co.uk)
